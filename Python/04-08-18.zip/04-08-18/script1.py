#!/usr/bin/python3

#import module1

from module1 import *
from module2 import countDistPairs
#from module1 import fib_func3, fib_func2
#from module1 import fib_func1
#from module1 import fib_func2 as fib2

#print(module1.fib_func3(45))
#print(module1.fib_func2(12))
#print(module1.fib_func1(12))

print(fib_func3(45))
print(fib_func2(12))
print(fib_func1(12))
print(is_prime1(29))
print(is_prime2(23))

print(countDistPairs(range(1,21), 9))

#print(fib_func3(45))
#print(fib_func2(12))
#print(fib_func1(12))

#print(fib2(12))
